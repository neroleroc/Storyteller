# Leroc Storyteller's Cut

Storyteller system for Foundry Virtual Tabletop, based upon Vampire the Masquerade 3rd Edition Ruleset.

Primary folder must be renamed to 'LSC' and placed in your Foundry VTT systems folder. 
( Default: %LocalAppData%\FoundryVTT\Data\systems\ )
